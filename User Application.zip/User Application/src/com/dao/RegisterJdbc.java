package com.dao;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.model.Login;
import com.model.Register;


public class RegisterJdbc {
	Connection con;
	PreparedStatement ps;
	int i;
	
	public Connection myConnection(){
		//1.load driver
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","System","Newuser123");
			System.out.println("Connection to db..");
	} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("catch connection..");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("catch connection..2");
			e.printStackTrace();
		} 
		return con;
	}
	
	public int saveData(List<com.model.Register> lst){
		try {
			con=myConnection();
			com.model.Register e = new com.model.Register();
			ps=con.prepareStatement("insert into REGEMP values(?,?,?,?,?)");
			ps.setInt(1,lst.get(0).getRegno());
			ps.setString(2,lst.get(0).getFname());
			ps.setString(3,lst.get(0).getUname());
			ps.setString(4, lst.get(0).getPass());
			ps.setDouble(5, lst.get(0).getSalary());
			i = ps.executeUpdate();
			con.close();
		} catch (SQLException e) {
			System.out.println("test11");
			e.printStackTrace();
		}
		catch(Exception e){
			System.out.println("global.."+e);
		}
		return i;
	}
	
	
	public boolean validateData(List<Login> ls) {
		List<Register> lr = getAllData();
		int flag=0;
		Iterator<Register> itr = lr.iterator();
		while(itr.hasNext()){
			Register r = itr.next();
			if(ls.get(0).getUname().equals(r.getUname()) && ls.get(0).getPass().equals(r.getPass())) {
				flag=1;	
				break;
				}
			else {
				continue;
			}
		}
		if(flag==1)
			return true;
		else
			return false;
		}

	
	public List<Register> getAllData()
	{
		List<Register> lst=new LinkedList<Register>();
		con=myConnection();
		try
		{
		Statement s=
					con.createStatement
					(ResultSet.TYPE_SCROLL_SENSITIVE,
							ResultSet.CONCUR_READ_ONLY);
			ResultSet rs=s.executeQuery("select * from REGEMP");
			while(rs.next())
			{
				Register u=new Register();
				u.setRegno(rs.getInt("regno"));
				u.setFname(rs.getString("fname"));
				u.setUname(rs.getString("uname"));
				u.setPass(rs.getString("pass"));
				u.setSalary(rs.getDouble("balance"));
				lst.add(u);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return lst;
	}

	
}
