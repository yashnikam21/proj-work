package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jdt.internal.compiler.ast.ArrayAllocationExpression;

import com.dao.RegisterJdbc;
import com.model.Register;

/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int regno = Integer.parseInt(request.getParameter("regno"));
		String fname = request.getParameter("fname");
		String uname = request.getParameter("uname");
		String pass = request.getParameter("pass");
		Double amt = Double.parseDouble(request.getParameter("amt"));
		
		com.model.Register r = new Register();
		r.setRegno(regno);
		r.setFname(fname);
		r.setUname(uname);
		r.setPass(pass);
		r.setSalary(amt);
		
		List<Register> lst = new ArrayList<Register>();
		lst.add(r);
		
		RegisterJdbc rj = new RegisterJdbc();
		rj.saveData(lst);
		PrintWriter pw = response.getWriter();
		response.sendRedirect("Login.jsp");
		response.getWriter().append("Served at: ").append(request.getContextPath());
		rj.getAllData();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
